package com.Jobxpress.Jobxpress.Controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AgendaController {

    // Ruta para mostrar la agenda
    @GetMapping("/agendapres")
    public String mostrarAgenda() {
        return "agendapres";
    }

}
