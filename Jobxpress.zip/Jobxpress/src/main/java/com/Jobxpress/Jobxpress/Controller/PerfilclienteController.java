package com.Jobxpress.Jobxpress.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PerfilclienteController {

    @GetMapping("/perfil")
    public String perfilCliente() {
        return "perfilcliente"; 
        // Carga la vista: src/main/resources/templates/cliente/perfil.html
    }
}

