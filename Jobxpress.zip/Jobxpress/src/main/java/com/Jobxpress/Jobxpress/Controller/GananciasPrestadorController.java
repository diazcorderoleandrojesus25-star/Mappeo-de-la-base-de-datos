package com.Jobxpress.Jobxpress.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class GananciasPrestadorController {

    @GetMapping("/gananciasprestador")
    public String gananciasprestador() {
        return "gananciasprestador";
    }
}
