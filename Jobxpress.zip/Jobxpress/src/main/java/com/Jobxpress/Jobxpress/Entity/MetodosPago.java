package com.Jobxpress.Jobxpress.Entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "metodos_pago")
public class MetodosPago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_metod_pago;

    private String formas_pago;

    @OneToMany(mappedBy = "metodoPago")
    private List<Pago> pagos;

    public Integer getId_metod_pago() {
        return id_metod_pago;
    }

    public void setId_metod_pago(Integer id_metod_pago) {
        this.id_metod_pago = id_metod_pago;
    }

    public String getFormas_pago() {
        return formas_pago;
    }

    public void setFormas_pago(String formas_pago) {
        this.formas_pago = formas_pago;
    }

    public List<Pago> getPagos() {
        return pagos;
    }

    public void setPagos(List<Pago> pagos) {
        this.pagos = pagos;
    }

    
}

