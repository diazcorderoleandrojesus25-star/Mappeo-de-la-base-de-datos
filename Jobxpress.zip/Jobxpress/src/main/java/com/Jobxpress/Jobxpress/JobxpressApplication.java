package com.Jobxpress.Jobxpress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobxpressApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobxpressApplication.class, args);
	}

}
