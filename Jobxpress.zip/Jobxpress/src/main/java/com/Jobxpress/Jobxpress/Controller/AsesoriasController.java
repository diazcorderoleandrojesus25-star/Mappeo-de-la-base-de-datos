package com.Jobxpress.Jobxpress.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AsesoriasController {

    @GetMapping("/asesorias")
    public String asesorias() {
        return "asesorias";  // nombre del html SIN .html
    }
}
