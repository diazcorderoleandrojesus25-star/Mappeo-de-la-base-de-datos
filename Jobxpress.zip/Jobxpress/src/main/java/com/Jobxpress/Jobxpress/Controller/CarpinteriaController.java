package com.Jobxpress.Jobxpress.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CarpinteriaController {

    @GetMapping("/carpinteria")
    public String carpinteria() {
        return "carpinteria"; // Nombre del HTML
    }
}
