package com.Jobxpress.Jobxpress.Controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Controller
public class PlomeriaController {

    @GetMapping("/plomeria")
    public String mostrarPlomeria(Model model) {

        model.addAttribute("numeros", 
                IntStream.rangeClosed(1, 9).boxed().collect(Collectors.toList())
        );

        return "plomeria";  // carga plomeria.html
    }
}
