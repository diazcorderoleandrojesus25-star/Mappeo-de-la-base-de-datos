package com.Jobxpress.Jobxpress.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class InstalacionnequiController {

    @GetMapping("/instalacion-equipos")
    public String instalacionEquipos() {
        return "instalacionnequi"; // Nombre del archivo HTML en templates
    }
}
