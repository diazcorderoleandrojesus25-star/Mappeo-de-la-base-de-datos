package com.Jobxpress.Jobxpress.Entity;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "pago")
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_pago;

    @ManyToOne
    @JoinColumn(name = "id_metodo_pago")
    private MetodosPago metodoPago;

    @ManyToOne
    @JoinColumn(name = "id_contratacion")
    private Contratacion contratacion;

    private Double monto;
    private Date fecha_pago;
    public Integer getId_pago() {
        return id_pago;
    }
    public void setId_pago(Integer id_pago) {
        this.id_pago = id_pago;
    }
    public MetodosPago getMetodoPago() {
        return metodoPago;
    }
    public void setMetodoPago(MetodosPago metodoPago) {
        this.metodoPago = metodoPago;
    }
    public Contratacion getContratacion() {
        return contratacion;
    }
    public void setContratacion(Contratacion contratacion) {
        this.contratacion = contratacion;
    }
    public Double getMonto() {
        return monto;
    }
    public void setMonto(Double monto) {
        this.monto = monto;
    }
    public Date getFecha_pago() {
        return fecha_pago;
    }
    public void setFecha_pago(Date fecha_pago) {
        this.fecha_pago = fecha_pago;
    }

    
}
